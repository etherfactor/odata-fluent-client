import { ODataClient } from "@ethergizmos/odata-fluent-client";
import { extendUrl } from "@ethergizmos/odata-fluent-client/src/utils/http";

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';

interface Chatbot {
  id: number;
  name: string;
}

console.log("test");

console.log(extendUrl("https://localhost:7000/api/v0.1", "chatbots"));

async function main() {
  try {
    const client = new ODataClient({
      http: { headers: {} },
      serviceUrl: "https://localhost:7000/api/v0.1",
      routingType: "parentheses",
    });
    
    const entity = client.createEntityClient({} as Chatbot, {
      entitySet: "chatbots",
      readSet: "GET",
    });
    
    const result = entity
      .set
      .count()
      .execute();
    
    console.log(result);
    
    console.log(await result.count);
    console.log(await result.data);
    for await (const entity of result.iterator) {
      console.log(entity);
    }
  } catch (err) {
    console.log("hit error");
    console.log(err);
  }
}

main()
  .then(() => {
    console.log("resolved");
  })
  .catch(() => {
    console.log("rejected");
  });
